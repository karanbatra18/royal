<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="">
                        Royal Matrimonial
                    </a>
                </li>
                <li>
                    <a href="">
                        About Us
                    </a>
                </li>
             
            </ul>
        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="" target="_blank">Royal Matrimonial</a> for a better web.
        </div>
    </div>

</footer>